import java.util.*;
import java.io.*;
//http://www.learn4master.com/algorithms/leetcode-serialize-and-deserialize-binary-tree-java used for serialize and deserialize methods
public class CelebrityGuesser {
    public static void main(String[] args) throws IOException {
        System.out.println("This is a celebrity guesser for NCIS characters. Please select a character and answer the questions truthfully for the best results.\n Not all characters are included, so be sure to choose a popular one.");
        System.out.println("Type -h to relist this information.");
        String s = fromtxt();
        TreeNode node = deserialize(s);
        game(node);
    }



    public static String serialize(TreeNode node) {
        if(node == null) { return "";}//  if the node is null, then returns an empty string
        LinkedList<TreeNode> list = new LinkedList<>();// creates a new linked list of treenodes
        list.add(node);// adds the given node to our linked list
        StringBuilder s = new StringBuilder();//creates a new string builder to make our string of node values
        while (!list.isEmpty()) {//creates a while loop checking if hte list is empty
            TreeNode node2 = list.poll();//creates a new temporary node and sets it to the top node of the list and removes it from the list
            if(node2 == null) {//checks to see if the temporary node is null
                s.append("null, ");//if they are null, adds a null placeholder to the stringbuilder
            } else {
                s.append(node2.getValue() +", ");//appends the value of our node(the string text ) to the string builder
                list.add(node2.getLeft());//adds the left of the node to the list
                list.add(node2.getRight());//adds the right of the node to the list
            }
        }
        return s.toString().trim();//returns the string builder cast to a string and trimmed
    }

    public static TreeNode deserialize(String s) {
        if(s.equals("") ) { return null; }//if the string is empty, returns null
        String[] split = s.split(", ");//splits the string at the index of ", "
        if(split.length == 0) {return null; }//if there are no splits, return null
        LinkedList<TreeNode> list = new LinkedList<>();//creates a new linked list of type treenode
        TreeNode root = new TreeNode(split[0]);//creates a new treenode root and sets it to the first item in split
        list.add(root);//adds the root treenode to the list
        TreeNode node = null;//creates another temp treenode
        String val;//creates a temp string called val
        for(int i = 1; i < split.length;) {//for statement for length of split
            node = list.poll();//sets our temp node to the top item of the list and deletes it
            val = split[i++];//sets our val equal to the index i plus 1 of split
            if(val.equals("null")) {// if our val is null,
                node.setLeft(null);//it sets the left of our node to null
            } else {
                node.setLeft(new TreeNode(val));//else sets the node equal to the value of val
                list.add(node.getLeft());//adds the left node to the list
            }
            if(i < split.length) {//if i is less than the lenght
                val = split[i++];//sets val to the index i plus 1 of split
                if(val.equals("null")) {//if value is null,
                    node.setRight(null);//sets the right of the node to null
                } else {
                    node.setRight(new TreeNode(val));//else sets the right of the node to the value of val
                    list.add(node.getRight());//adds the right node to the list
                }
            }
        }
        return root;//returns the root node
    }
    public static String fromtxt() {
        String text="";
        try {
            File myfile = new File("src/Tree.txt");
            Scanner filescanner = new Scanner(myfile);
             text = filescanner.nextLine();

        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return text;
    }

    public static void game(TreeNode node) throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.println(node.getValue() + " y/n");
        String response = scanner.nextLine();
        //base case
        // if yes and left and right nodes are null
        if(response.equals("y") && node.getLeft() == null && node.getRight() == null) {
            System.out.println("Congratulations! I guessed your character!");
        }
        else if(response.equals("n") && node.getLeft() == null && node.getRight() == null) {
            System.out.println("Oh no! Please type who you were thinking of and I'll get to adding them ASAP");
            String unknown = scanner.nextLine();
            FileWriter myfile = new FileWriter("src/nodestoadd.txt",true);
            myfile.write(unknown + "\n");
            myfile.close();

        }
        //recursive case
        if(response.equals("y") && node.getLeft() != null) {
            game(node.getLeft());
        }
        else if(response.equals("n") && node.getRight() != null){
            game(node.getRight());
        }
        if(response.equals("-h")) {
            System.out.println("This is a celebrity guesser for NCIS characters. Please select a character and answer the questions truthfully for the best results. Not all characters are included, so be sure to choose a popular one.");
            System.out.println("Type -h to relist the commands. When in the game, respond with only \"y\" or \"n\"");
            game(node);
        }
    }

}
